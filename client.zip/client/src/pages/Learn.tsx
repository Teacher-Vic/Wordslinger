import { useState, useEffect } from "react";
import { type Level, type Word, type WordHistoryItem } from "@shared/schema";
import WordDisplay from "@/components/WordDisplay";
import ActionButtons from "@/components/ActionButtons";
import { getRandomWord } from "@/lib/mockWords";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Settings, History, Heart } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import LevelSelector from "@/components/LevelSelector";
import WordList from "@/components/WordList";

export default function Learn() {
  const { toast } = useToast();
  const [level, setLevel] = useState<Level>(() => {
    const saved = localStorage.getItem('wordslinger-level');
    return (saved as Level) || 'beginner';
  });
  const [currentWord, setCurrentWord] = useState<Word | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('wordslinger-favorites');
    return new Set(saved ? JSON.parse(saved) : []);
  });
  const [history, setHistory] = useState<WordHistoryItem[]>(() => {
    const saved = localStorage.getItem('wordslinger-history');
    return saved ? JSON.parse(saved) : [];
  });
  const [showLevelSelector, setShowLevelSelector] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [isFirstVisit, setIsFirstVisit] = useState(() => {
    return !localStorage.getItem('wordslinger-level');
  });

  useEffect(() => {
    if (!isFirstVisit) {
      loadNewWord();
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('wordslinger-level', level);
  }, [level]);

  useEffect(() => {
    localStorage.setItem('wordslinger-favorites', JSON.stringify(Array.from(favorites)));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('wordslinger-history', JSON.stringify(history));
  }, [history]);

  const loadNewWord = () => {
    const word = getRandomWord(level);
    setCurrentWord(word);
    
    // Add to history
    const historyItem: WordHistoryItem = {
      wordId: word.id,
      word: word.word,
      level: word.level,
      viewedAt: new Date()
    };
    setHistory(prev => [historyItem, ...prev.slice(0, 49)]);
  };

  const handleLevelChange = (newLevel: Level) => {
    setLevel(newLevel);
    if (isFirstVisit) {
      setIsFirstVisit(false);
      loadNewWord();
    }
    toast({
      title: "Level Updated",
      description: `Now showing ${newLevel} vocabulary`
    });
  };

  const toggleFavorite = () => {
    if (!currentWord) return;
    
    const newFavorites = new Set(favorites);
    if (newFavorites.has(currentWord.id)) {
      newFavorites.delete(currentWord.id);
      toast({
        title: "Removed from favorites",
        description: `${currentWord.word} has been removed from your favorites`
      });
    } else {
      newFavorites.add(currentWord.id);
      toast({
        title: "Saved to favorites",
        description: `${currentWord.word} has been added to your favorites`
      });
    }
    setFavorites(newFavorites);
  };

  if (isFirstVisit) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <LevelSelector
          selectedLevel={level}
          onLevelChange={handleLevelChange}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-2xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold" data-testid="text-app-title">Wordslinger</h1>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowFavorites(true)}
              data-testid="button-favorites"
            >
              <Heart className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowHistory(true)}
              data-testid="button-history"
            >
              <History className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowLevelSelector(true)}
              data-testid="button-settings"
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-6 py-12">
        <div className="space-y-8">
          {currentWord ? (
            <>
              <WordDisplay word={currentWord} />
              <ActionButtons
                isFavorite={favorites.has(currentWord.id)}
                onSave={toggleFavorite}
                onNewWord={loadNewWord}
              />
            </>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">Ready to learn?</p>
              <Button onClick={loadNewWord} size="lg" data-testid="button-start-learning">
                Start Learning
              </Button>
            </div>
          )}
        </div>
      </main>

      <Dialog open={showLevelSelector} onOpenChange={setShowLevelSelector}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Change Level</DialogTitle>
          </DialogHeader>
          <LevelSelector
            selectedLevel={level}
            onLevelChange={handleLevelChange}
            onClose={() => setShowLevelSelector(false)}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Word History</DialogTitle>
          </DialogHeader>
          <WordList
            words={history}
            onWordClick={(id) => {
              console.log('Navigate to word:', id);
              toast({
                title: "Word History",
                description: "Full word lookup will be available in the complete version"
              });
            }}
            emptyMessage="You haven't learned any words yet. Start exploring!"
          />
        </DialogContent>
      </Dialog>

      <Dialog open={showFavorites} onOpenChange={setShowFavorites}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Favorite Words</DialogTitle>
          </DialogHeader>
          <WordList
            words={history.filter(item => favorites.has(item.wordId))}
            onWordClick={(id) => {
              console.log('Navigate to favorite word:', id);
              toast({
                title: "Favorite Words",
                description: "Full word lookup will be available in the complete version"
              });
            }}
            emptyMessage="You haven't saved any favorites yet. Click the heart icon to save words!"
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
