import { type Level } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface LevelBadgeProps {
  level: Level;
}

const levelLabels: Record<Level, string> = {
  beginner: 'Beginner',
  journey: 'Journey',
  advanced: 'Advanced',
  master: 'Master'
};

export default function LevelBadge({ level }: LevelBadgeProps) {
  return (
    <Badge 
      variant="secondary" 
      className="uppercase text-xs tracking-wider font-semibold"
      data-testid="badge-level"
    >
      {levelLabels[level]}
    </Badge>
  );
}
