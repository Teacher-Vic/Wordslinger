import { type Level } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface LevelSelectorProps {
  selectedLevel: Level;
  onLevelChange: (level: Level) => void;
  onClose?: () => void;
}

const levels: { value: Level; label: string; description: string }[] = [
  {
    value: 'beginner',
    label: 'Beginner',
    description: 'Simple everyday vocabulary'
  },
  {
    value: 'journey',
    label: 'Journey',
    description: 'Intermediate verbs and adjectives'
  },
  {
    value: 'advanced',
    label: 'Advanced',
    description: 'Complex and formal words'
  },
  {
    value: 'master',
    label: 'Master',
    description: 'Rare, literary, or academic vocabulary'
  }
];

export default function LevelSelector({ selectedLevel, onLevelChange, onClose }: LevelSelectorProps) {
  return (
    <div className="w-full max-w-2xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2" data-testid="text-select-level-title">
          Select Your Level
        </h2>
        <p className="text-muted-foreground">
          Choose the vocabulary level that matches your current knowledge
        </p>
      </div>

      <div className="grid gap-4">
        {levels.map((level) => (
          <Card
            key={level.value}
            className={`p-6 cursor-pointer transition-all hover-elevate ${
              selectedLevel === level.value ? 'ring-2 ring-ring' : ''
            }`}
            onClick={() => {
              onLevelChange(level.value);
              onClose?.();
            }}
            data-testid={`card-level-${level.value}`}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold mb-1">{level.label}</h3>
                <p className="text-sm text-muted-foreground">{level.description}</p>
              </div>
              {selectedLevel === level.value && (
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                  <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
