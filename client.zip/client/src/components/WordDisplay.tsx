import { type Word } from "@shared/schema";
import LevelBadge from "./LevelBadge";
import { Card } from "@/components/ui/card";

interface WordDisplayProps {
  word: Word;
}

export default function WordDisplay({ word }: WordDisplayProps) {
  return (
    <Card className="p-8 md:p-12 shadow-lg" data-testid="card-word-display">
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <h1 
            className="text-5xl md:text-6xl font-bold tracking-tight mb-2"
            data-testid="text-word"
          >
            {word.word}
          </h1>
          <p 
            className="text-sm italic text-muted-foreground"
            data-testid="text-part-of-speech"
          >
            {word.partOfSpeech}
          </p>
        </div>
        <LevelBadge level={word.level} />
      </div>

      <div className="mb-8">
        <p 
          className="text-lg leading-relaxed font-serif"
          data-testid="text-definition"
        >
          {word.definition}
        </p>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
          Examples
        </h3>
        {word.examples.map((example, index) => (
          <div 
            key={index} 
            className="py-3 border-b border-border last:border-0"
            data-testid={`example-${index}`}
          >
            <p className="text-base leading-loose mb-1">
              "{example.text}"
            </p>
            {example.attribution && (
              <p 
                className="text-sm italic text-muted-foreground text-right"
                data-testid={`attribution-${index}`}
              >
                — {example.attribution}
              </p>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}
