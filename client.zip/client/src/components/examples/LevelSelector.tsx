import { useState } from 'react';
import LevelSelector from '../LevelSelector';
import { type Level } from '@shared/schema';

export default function LevelSelectorExample() {
  const [level, setLevel] = useState<Level>('journey');

  return (
    <LevelSelector 
      selectedLevel={level} 
      onLevelChange={setLevel}
    />
  );
}
