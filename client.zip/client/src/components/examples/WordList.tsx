import WordList from '../WordList';

export default function WordListExample() {
  const mockWords = [
    {
      wordId: '1',
      word: 'Serendipity',
      level: 'master' as const,
      viewedAt: new Date(Date.now() - 1000 * 60 * 5)
    },
    {
      wordId: '2',
      word: 'Ephemeral',
      level: 'advanced' as const,
      viewedAt: new Date(Date.now() - 1000 * 60 * 60 * 2)
    },
    {
      wordId: '3',
      word: 'Ameliorate',
      level: 'journey' as const,
      viewedAt: new Date(Date.now() - 1000 * 60 * 60 * 24)
    }
  ];

  return (
    <WordList 
      words={mockWords} 
      onWordClick={(id) => console.log('Word clicked:', id)}
    />
  );
}
