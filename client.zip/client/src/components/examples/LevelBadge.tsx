import LevelBadge from '../LevelBadge';

export default function LevelBadgeExample() {
  return (
    <div className="flex gap-4 flex-wrap">
      <LevelBadge level="beginner" />
      <LevelBadge level="journey" />
      <LevelBadge level="advanced" />
      <LevelBadge level="master" />
    </div>
  );
}
