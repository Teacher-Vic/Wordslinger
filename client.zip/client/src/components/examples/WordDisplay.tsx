import WordDisplay from '../WordDisplay';

export default function WordDisplayExample() {
  const mockWord = {
    id: '1',
    word: 'Serendipity',
    level: 'master' as const,
    partOfSpeech: 'Noun',
    definition: 'The occurrence of events by chance in a happy or beneficial way.',
    examples: [
      {
        text: 'Serendipity is looking in a haystack for a needle and discovering a farmer\'s daughter.',
        attribution: 'Julius Comroe Jr.'
      },
      {
        text: 'Some of the greatest discoveries in science have come about through serendipity.',
      },
      {
        text: 'Meeting her was pure serendipity.',
      }
    ]
  };

  return <WordDisplay word={mockWord} />;
}
