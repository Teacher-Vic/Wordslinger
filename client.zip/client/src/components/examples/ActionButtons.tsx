import { useState } from 'react';
import ActionButtons from '../ActionButtons';

export default function ActionButtonsExample() {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <ActionButtons
      isFavorite={isFavorite}
      onSave={() => {
        setIsFavorite(!isFavorite);
        console.log('Save word triggered');
      }}
      onNewWord={() => console.log('New word triggered')}
    />
  );
}
