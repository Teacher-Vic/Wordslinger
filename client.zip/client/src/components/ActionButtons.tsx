import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";

interface ActionButtonsProps {
  isFavorite: boolean;
  onSave: () => void;
  onNewWord: () => void;
  disabled?: boolean;
}

export default function ActionButtons({ 
  isFavorite, 
  onSave, 
  onNewWord,
  disabled = false 
}: ActionButtonsProps) {
  return (
    <div className="flex gap-4 justify-center flex-wrap">
      <Button
        variant={isFavorite ? "default" : "outline"}
        size="lg"
        onClick={onSave}
        disabled={disabled}
        className="min-w-[140px]"
        data-testid="button-save-word"
      >
        <Heart className={`w-4 h-4 mr-2 ${isFavorite ? 'fill-current' : ''}`} />
        {isFavorite ? 'Saved' : 'Save Word'}
      </Button>
      <Button
        variant="default"
        size="lg"
        onClick={onNewWord}
        disabled={disabled}
        className="min-w-[140px]"
        data-testid="button-new-word"
      >
        New Word
      </Button>
    </div>
  );
}
