import { type WordHistoryItem } from "@shared/schema";
import { Card } from "@/components/ui/card";
import LevelBadge from "./LevelBadge";
import { formatDistanceToNow } from "date-fns";

interface WordListProps {
  words: WordHistoryItem[];
  onWordClick: (wordId: string) => void;
  emptyMessage?: string;
}

export default function WordList({ words, onWordClick, emptyMessage = "No words yet" }: WordListProps) {
  if (words.length === 0) {
    return (
      <Card className="p-12 text-center">
        <p className="text-muted-foreground" data-testid="text-empty-message">
          {emptyMessage}
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {words.map((item) => (
        <Card
          key={item.wordId}
          className="p-4 cursor-pointer hover-elevate active-elevate-2"
          onClick={() => onWordClick(item.wordId)}
          data-testid={`card-word-${item.wordId}`}
        >
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-semibold truncate" data-testid={`text-word-${item.wordId}`}>
                {item.word}
              </h3>
              <p className="text-sm text-muted-foreground">
                {formatDistanceToNow(new Date(item.viewedAt), { addSuffix: true })}
              </p>
            </div>
            <LevelBadge level={item.level} />
          </div>
        </Card>
      ))}
    </div>
  );
}
