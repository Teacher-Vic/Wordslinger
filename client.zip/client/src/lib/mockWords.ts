import { type Word, type Level } from "@shared/schema";

// TODO: remove mock functionality - this is for prototype only
export const mockWordsDatabase: Record<Level, Word[]> = {
  beginner: [
    {
      id: 'b1',
      word: 'Happy',
      level: 'beginner',
      partOfSpeech: 'Adjective',
      definition: 'Feeling or showing pleasure or contentment.',
      examples: [
        { text: 'I am so happy to see you!' },
        { text: 'She had a happy childhood full of laughter and joy.' },
        { text: 'The children were happy playing in the park.' }
      ]
    },
    {
      id: 'b2',
      word: 'Friend',
      level: 'beginner',
      partOfSpeech: 'Noun',
      definition: 'A person with whom one has a bond of mutual affection.',
      examples: [
        { text: 'She is my best friend.' },
        { text: 'A friend in need is a friend indeed.' },
        { text: 'He made many friends at school.' }
      ]
    },
    {
      id: 'b3',
      word: 'Beautiful',
      level: 'beginner',
      partOfSpeech: 'Adjective',
      definition: 'Pleasing the senses or mind aesthetically.',
      examples: [
        { text: 'What a beautiful day!' },
        { text: 'She wore a beautiful dress to the party.' },
        { text: 'The sunset was absolutely beautiful.' }
      ]
    }
  ],
  journey: [
    {
      id: 'j1',
      word: 'Contemplate',
      level: 'journey',
      partOfSpeech: 'Verb',
      definition: 'To think about something deeply and carefully.',
      examples: [
        { text: 'He sat quietly, contemplating his next move.' },
        { text: 'She contemplated the meaning of life while watching the stars.' },
        { text: 'I need time to contemplate this important decision.' }
      ]
    },
    {
      id: 'j2',
      word: 'Eloquent',
      level: 'journey',
      partOfSpeech: 'Adjective',
      definition: 'Fluent or persuasive in speaking or writing.',
      examples: [
        { text: 'The speaker gave an eloquent speech that moved the audience.', attribution: 'Historical Record' },
        { text: 'Her eloquent words brought tears to many eyes.' },
        { text: 'He was known for his eloquent writing style.' }
      ]
    },
    {
      id: 'j3',
      word: 'Resilient',
      level: 'journey',
      partOfSpeech: 'Adjective',
      definition: 'Able to withstand or recover quickly from difficult conditions.',
      examples: [
        { text: 'Children are remarkably resilient in the face of adversity.' },
        { text: 'The resilient community rebuilt after the disaster.' },
        { text: 'She proved to be resilient, bouncing back from every setback.' }
      ]
    }
  ],
  advanced: [
    {
      id: 'a1',
      word: 'Ephemeral',
      level: 'advanced',
      partOfSpeech: 'Adjective',
      definition: 'Lasting for a very short time; transient.',
      examples: [
        { text: 'Fame is ephemeral, but character lasts forever.' },
        { text: 'The beauty of cherry blossoms is ephemeral, lasting only a few weeks.' },
        { text: 'Social media trends are often ephemeral, disappearing as quickly as they appear.' }
      ]
    },
    {
      id: 'a2',
      word: 'Ubiquitous',
      level: 'advanced',
      partOfSpeech: 'Adjective',
      definition: 'Present, appearing, or found everywhere.',
      examples: [
        { text: 'Smartphones have become ubiquitous in modern society.' },
        { text: 'Coffee shops seem to be ubiquitous in this city.' },
        { text: 'The ubiquitous presence of technology has changed how we communicate.' }
      ]
    },
    {
      id: 'a3',
      word: 'Ameliorate',
      level: 'advanced',
      partOfSpeech: 'Verb',
      definition: 'To make something bad or unsatisfactory better.',
      examples: [
        { text: 'The new policy aims to ameliorate working conditions.' },
        { text: 'Nothing could ameliorate his disappointment.' },
        { text: 'Efforts to ameliorate poverty have met with mixed success.' }
      ]
    }
  ],
  master: [
    {
      id: 'm1',
      word: 'Serendipity',
      level: 'master',
      partOfSpeech: 'Noun',
      definition: 'The occurrence of events by chance in a happy or beneficial way.',
      examples: [
        { text: 'Serendipity is looking in a haystack for a needle and discovering a farmer\'s daughter.', attribution: 'Julius Comroe Jr.' },
        { text: 'Some of the greatest discoveries in science have come about through serendipity.' },
        { text: 'Meeting her was pure serendipity.' }
      ]
    },
    {
      id: 'm2',
      word: 'Perspicacious',
      level: 'master',
      partOfSpeech: 'Adjective',
      definition: 'Having a ready insight into and understanding of things; mentally sharp or discerning.',
      examples: [
        { text: 'Her perspicacious analysis of the situation impressed everyone.' },
        { text: 'A perspicacious observer would have noticed the subtle clues.' },
        { text: 'His perspicacious judgment made him an excellent advisor.' }
      ]
    },
    {
      id: 'm3',
      word: 'Ineffable',
      level: 'master',
      partOfSpeech: 'Adjective',
      definition: 'Too great or extreme to be expressed or described in words.',
      examples: [
        { text: 'The beauty of the mountain vista was ineffable.', attribution: 'Travel Journal' },
        { text: 'She experienced an ineffable sense of peace.' },
        { text: 'The ineffable joy of holding her newborn child brought tears to her eyes.' }
      ]
    }
  ]
};

export function getRandomWord(level: Level): Word {
  const words = mockWordsDatabase[level];
  return words[Math.floor(Math.random() * words.length)];
}
